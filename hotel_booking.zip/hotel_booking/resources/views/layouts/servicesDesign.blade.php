<div class="card card-service w-100 mb-2">
    <div class="card-header">
        <h4 class="h4">Handpicked Hotels</h4>
    </div>
    <div class="card-body">
        <p>All hotels on our website are tested according to various criteria. You can be sure of your choice.</p>
    </div>
</div>