
  @include('layout\header');
  @include('layout\aside');
  
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create Account</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Profile Managment</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
            </div>
          </div>
          <!-- /.card-header -->
          <form id="frmregister">
          <div class="card-body">
            <div class="row">
          
              <div class="col-md-6">
                <div class="form-group">
                  <label>Name
                    <?php $data = session('userlogin'); ?>
                  </label>
                  <input type="text" name="name" id="name" class="form-control" value="<?php if(!empty($data)){ echo $data[0]['name']; } ?>" />
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Password</label>

                  <div class="input-group my-colorpicker2">
                    <input type="password" name="password" id="password" class="form-control">

                    <div class="input-group-append">
                      <span class="input-group-text"><i class="far fa-eye"></i></span>
                    </div>
                  </div>
                  <!-- /.input group -->
                </div>
                <!-- /.form-group -->
              </div>
              
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>Email</label>
                  <input type="name" class="form-control" name="email" id="email" value="<?php if(!empty($data)){ echo $data[0]['email']; } ?>" />
                  
                </div>
                <!-- /.form-group -->
                <div class="form-group">
                  <label>Confirm Password</label>

                  <div class="input-group my-colorpicker2">
                    <input type="password" name="cpassword" id="cpassword" class="form-control">

                    <div class="input-group-append">
                      <span class="input-group-text"><i class="far fa-eye"></i></span>
                    </div>
                  </div>
                  <!-- /.input group -->
                </div>
                
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <input type="hidden" id="id" name="id" value="<?php if(!empty($data)){ echo $data[0]['id']; } ?>" />
            <div class="col-md-6">
                
                
                <div class="form-group">
                  <label>Image</label>
                  <div class="image">
          <img style="width: 120px;
    height: 139px;" src="/uploads/{{$data[0]['image']}}" class="img-circle elevation-2" alt="User Image">
        </div>
                  <div class="input-group my-colorpicker2">
                    <input type="file" name="image" id="image" class="form-control">

                    <div class="input-group-append">
                      <span class="input-group-text">Preview</span>
                    </div>
                  </div>
                  <!-- /.input group -->
                </div>
                <div class="form-group">
                <input class="btn btn-success" type="submit" name="btn-add" id="btn-add" />
                </div>
                <!-- /.form-group -->
              </div>
            <!-- /.row -->

            </form>
              
          
             <!-- Main content -->
    <section style="display:none" class="content">
      <div class="row">
      
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-header">
              <h3 class="card-title">
                Description
                <small>Notice or any information</small>
              </h3>
              <!-- tools box -->
              <div class="card-tools">
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                  <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fas fa-times"></i></button>
              </div>
              <!-- /. tools -->
            </div>
            <!-- /.card-header -->
            <div class="card-body pad">
              <div class="mb-3">
                <textarea class="textarea" placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
              </div>
             
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->
    </section>
    <!-- /.content -->
    <div id="myalert" class="toasts-top-right fixed myhide"><div class="toast bg-success fade show" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><strong id="title" class="mr-auto"></strong></div><div id="dbody" class="toast-body"></div></div></div>
          

        
          
               
                

                

              
              
    </section>
    <!-- /.content -->
  </div>
  @include('layout\footer');


  <script>
  /**********************************save************************************/

  $('#frmregister').on("submit",function(e){
    /// alert('work');
    ///return false;
    password = $('#password').val();
    cpassword = $('#cpassword').val();
    user_id = $('#id').val();
    if(user_id=='')
    {
      if(password!=cpassword)
    {
      $('#title').html('Error');
          
          $('#dbody').html('Password and confirm password should be match');

          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
         return false;
    }
    }
    
    e.preventDefault(); 
     var formData = new FormData();
  var other_data = $('#frmregister').serializeArray();
    $.each(other_data,function(key,input){
        formData.append(input.name,input.value);
    });
     if($('#image').val()!='')
      {
        formData.append("file", document.getElementById('image').files[0]);        
      } 
    $.ajax({
      type: "POST",
      url: "/saveaccount",
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      dataType: 'JSON',
       beforeSend:function(){
            $('#loader').removeClass('myhide');
            },
      success: function(data) {
        $('#loader').addClass('myhide');
        if(data.status==200)
        {
          $('#title').html('SUCCESS');
          
          $('#dbody').html(data.message);

          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
          
        }
        if(data.status==204)
        {
          $('#title').html('ERROR');
          
          $('#dbody').html(data.message);

          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
        }
        if(data.status==1000)
        {
          $('#title').html('Valdition Error');
          
         
          html = '<ul>'
          $.each(data.error, function(prefix,val){
           
           html = html+"<li>"+val[0]+"</li>";
          } );
          html = html+"</ul>";
         /// alert(html);
         
          $('#dbody').html(html);


          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
        }
      
            }
      });

  //ajax end 

    });
  
  </script>