
  @include('layout\header');
  @include('layout\aside');
  <style>
  .container{
    width: 50%; 
    margin: 0;
      
}
.myicon{
  font-size: 20px;
    font-weight: bold;
    color: red;
    /* border: 1px solid; */
    position: absolute;
}
.element{
    margin-bottom: 10px;
}

.add,.remove{
    border: 1px solid black;
    padding: 2px 10px;
}

.add:hover,.remove:hover{
    cursor: pointer;
}
  
  </style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Stock in</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active"><a href="/products">View Products</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Save Stock</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
              <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i></button>
            </div>
          </div>
          <!-- /.card-header -->
          <form id="frmregister">
          <div class="card-body">
            <div class="row">
          
              <div class="col-md-6">
                <div class="form-group">
                  <label>Product Title
                  </label>
                  <input type="text" name="product_title" id="pro_name" class="form-control" value="<?php if(!empty($data)){ echo $data[0]['title']; }else{
                    
                  } ?>" />
                </div>
               
              </div>
              
              <!-- /.col -->
              <div class="col-md-6">
                <div class="form-group">
                  <label>Price per item*</label>
                  <input type="number" onchange="gettotalprice(this.value)" class="form-control" name="price_par_item" id="pprice" value="<?php if(!empty($data)){ echo $data[0]['price_par_item']; } ?>" />
                  
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
            </div>
            <!--2nd row-->
            <div style="display: none" class="row">
          
          <div class="col-md-6">
            <div class="form-group">
              <label>Catgry
              </label>
              <select onchange="getsubcatgries(this.value)" id="catid" name="Catgry_Name" class="form-control">
  <option value="">Select</option>
              <?php 
foreach($catdata as $cat)
{
  if(!empty($data))
  {
    if($cat['id']==$data[0]['catgry_id'])
    {
      ?>
      <option selected value="<?php echo  $cat['id']; ?>"><?php echo $cat['name']; ?></option>
        <?php  
        continue;
    }
  }
  else
  {
    ?>
    <option value="<?php echo  $cat['id']; ?>"><?php echo $cat['name']; ?></option>
      <?php
  }
  
  
}

?>
              </select>
             
            </div>
           
          </div>
          
          <!-- /.col -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Subcatgry</label>
              <select name="subcatgry_name" id="sub_catgry" class="form-control">
              <option>select</option>
              
              </select>
              
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.col -->
        </div>

            <!--end of 2nd row-->
            <!--3nd row-->
            <div class="row">
          
          <div class="col-md-6">
            <div class="form-group">
              <label>Total Stock
              </label>
              <input type="number" onchange="gettotalprice(this.value)" name="Quantity" id="qty" value="<?php if(!empty($data)){ echo $data[0]['qty']; } ?>" class="form-control" value="<?php if(!empty($data)){ echo $data[0]['qty']; }else{} ?>" />
            </div>
           
          </div>
          
          <!-- /.col -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Total Ammount</label>
              <input type="number" class="form-control" name="Total_Ammount" id="tprice" value="<?php if(!empty($data)){ echo $data[0]['price']; }else{} ?>" />
              
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.col -->
        </div>

            <!--end of 3nd row-->
            <!--3nd row-->
            <div style="display: none" class="row">
          
          <div class="col-md-6">
            <div class="form-group">
              <label>supplier Name
              </label>
              <select class="form-control" name="supplier_name">
              <option>Select</option>
              <?php
foreach($supdata as $sp)
{
  if(!empty($data))
  {
    if($sp['id']==$data[0]['supplier_id'])
    {
    ?>
<option selected value="<?php echo  $sp['id']; ?>"><?php echo $sp['name']; ?></option>
  <?php
  continue; 
  }
  }
  else
  {
    ?>
    <option value="<?php echo  $sp['id']; ?>"><?php echo $sp['name']; ?></option>
      <?php
  }
  
  
}
              ?>
              </select>
            </div>
           
          </div>
          
          <!-- /.col -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Total Discount</label>
              <input type="number" onchange="gettotalprice(this.value)" class="form-control" name="discount" id="discount" value="<?php if(!empty($data)){ echo $data[0]['discount']; }else{} ?>"  />
              
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.col -->
        </div>
        <div class="row">
          
         
          
          <!-- /.col -->
          <div style="display: none" class="col-md-12">
            <div class="form-group">
              <label>Expiry Date
              
              </label>
              <input type="date" class="form-control" name="expiry_date" id="date" value="<?php if(!empty($data)){ echo $data[0]['expiry_date']; }else{} ?>" />
              
            </div>
            <!-- /.form-group -->
          </div>
          <!-- /.col -->
        </div>
        <!--for editor-->
        <div style="display: none" class="row">
      
        <div class="col-md-12">
          <div class="card card-outline card-info">
            <div class="card-header">
              <h3 class="card-title">
                Description
                <small>Notice or any information</small>
              </h3>
              <!-- tools box -->
              <div class="card-tools">
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="collapse" data-toggle="tooltip"
                        title="Collapse">
                  <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool btn-sm" data-card-widget="remove" data-toggle="tooltip"
                        title="Remove">
                  <i class="fas fa-times"></i></button>
              </div>
              <!-- /. tools -->
            </div>
            <!-- /.card-header -->
            <div class="card-body pad">
              <div class="mb-3">
                <textarea class="textarea"  name="description" id="description" placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php if(!empty($data)){ echo $data[0]['description']; }else{} ?></textarea>
              </div>
             
            </div>
          </div>
        </div>
        <!-- /.col-->
      </div>
      <!-- ./row -->


        <!--not for editor-->
<div style="display: none" class="row">
<?php
if(!empty($data))
{
  $images = $images = getproimages($data[0]['id']);
  foreach($images as $img)
                    {
                      $id = 'div_'.$img['id'];
?>
<div class="col-md-2" id="<?php echo $id; ?>" >

<img src="/uploads/{{$img['image']}}" height="130px" width="130px" >
<i class="myicon" onclick="deleteproimage('<?php echo $img['id']; ?>','<?php echo $img['image']; ?>')">X</i>
</div>

<?php
                    }

}

?>

</div>


        <label style="display: none">Stock Images
              </label>
        <div style="display: none" class="container" >

            <div class='element' id='div_1'>
                <input type='file' name="file" placeholder='Enter your skill' id='file_1' >&nbsp;<span class='add'>+</span>
            </div>
        </div>

            <!--end of 3nd row-->
            <input type="hidden" id="id" name="id" value="<?php if(!empty($data)){ echo $data[0]['id']; } ?>" />
            <div class="col-md-6">
                
                
               
                <div class="form-group">
                <input class="btn btn-success" type="submit" name="btn-add" id="btn-add" />
                </div>
                <!-- /.form-group -->
              </div>

            <!-- /.row -->

            </form>
              
          
             <!-- Main content -->
    
    <!-- /.content -->
    <div id="myalert" class="toasts-top-right fixed myhide"><div class="toast bg-success fade show" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><strong id="title" class="mr-auto"></strong></div><div id="dbody" class="toast-body"></div></div></div>
                  
    </section>
    <!-- /.content -->
   
  </div>
  
  @include('layout\footer');

  <script>
///function get total price
function gettotalprice(amt)
{
 // alert(amt);
  qty=$('#qty').val();
  pprice = $('#pprice').val();
  if(qty!=0 && pprice!=0 )
  {
    dis = $('#discount').val();
    if(dis>0)
    {
      tamt = qty*pprice;
      tamt = tamt-dis;
    }
    else
    {
      tamt = qty*pprice;
    }

$('#tprice').val(tamt);
  }
}

///functio delete image
function deleteproimage(id,path)
{
//  alert(id);

  var formData = new FormData();

        formData.append('id',id);
        formData.append('path',path);
    
        $.ajax({
      type: "POST",
      url: "/deleteproimage",
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      dataType: 'JSON',
       beforeSend:function(){
             ///   $('#btn_result').html('Creating...');
            },
      success: function(data) {
        if(data.status==200)
        {
          $('#div_'+id).hide('slow');
        }
        if(data.status==204)
        {
   alert(data.message);
        }
        
            }
      }); 
       
}

//end of delete image 
//end of get totalprice
/**********************************save************************************/

  $('#frmregister').on("submit",function(e){
  //  var v =$('#description').val();
   // alert(v);
    //return false;

 //   post_description = CKEDITOR.instances.editor1.getData();

	//		formData.append("post_description", post_description);
    e.preventDefault(); 
     var formData = new FormData();
  var other_data = $('#frmregister').serializeArray();
    $.each(other_data,function(key,input){
        formData.append(input.name,input.value);
    });
    timages=localStorage.getItem("images");
		for(i=1; i<=parseInt(timages); i++)
		{
		   if($('#file_'+i).val()!='')
      {
        formData.append("file[]", document.getElementById('file_'+i).files[0]);
        
      } 
		}
    $.ajax({
      type: "POST",
      url: "/saveproductsdata",
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      dataType: 'JSON',
       beforeSend:function(){
            $('#loader').removeClass('myhide');
            },
      success: function(data) {
        $('#loader').addClass('myhide');
        if(data.status==200)
        {
          $('#title').html('SUCCESS');
          
          $('#dbody').html(data.message);

          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
          
        }
        if(data.status==204)
        {
          $('#title').html('ERROR');
          
          $('#dbody').html(data.message);

          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
        }
        if(data.status==1000)
        {
          $('#title').html('Valdition Error');
          
         
          html = '<ul>'
          $.each(data.error, function(prefix,val){
           
           html = html+"<li>"+val[0]+"</li>";
          } );
          html = html+"</ul>";
         /// alert(html);
         
          $('#dbody').html(html);


          $('#myalert').removeClass('myhide');
          setTimeout(function(){
            $('#myalert').addClass('myhide');
         }, 3000);
        }
      
            }
      });

  //ajax end 

    });

    ////function of getsubcatgries
function getsubcatgries(cid)
{
        var formData = new FormData();

        formData.append('catgry_id',cid);
    
        $.ajax({
      type: "POST",
      url: "/getsubcatgries",
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      data: formData,
      cache: false,
      contentType: false,
      processData: false,
      dataType: 'JSON',
       beforeSend:function(){
             ///   $('#btn_result').html('Creating...');
            },
      success: function(data) {
        
        $('#sub_catgry').html(data.html);
            }
      });       
}


//end of function sub get
 
  </script>
  <script>
  $(document).ready(function(){
	localStorage.setItem("images",1);
//localstorage.setItem('images',1);
    // Add new element
    $(".add").click(function(){
        timages=localStorage.getItem("images");
		tot = parseInt(timages)+1;
		localStorage.setItem("images",tot);
		ct=localStorage.getItem("images");
		alert(ct);
        // Finding total number of elements added
        var total_element = $(".element").length;
                    
        // last <div> with element class id
        var lastid = $(".element:last").attr("id");
        var split_id = lastid.split("_");
        var nextindex = Number(split_id[1]) + 1;

        var max = 5;
        // Check total number elements
        if(total_element < max ){
            // Adding new div container after last occurance of element class
            $(".element:last").after("<div class='element' id='div_"+ nextindex +"'></div>");
                        
            // Adding element to <div>
            $("#div_" + nextindex).append("<input name='file' type='file' placeholder='Enter your skill' id='file_"+ nextindex +"'>&nbsp;<span id='remove_" + nextindex + "' class='remove'>-</span>");
                    
        }
                    
    });

    // Remove element
    $('.container').on('click','.remove',function(){
        timages=localStorage.getItem("images");
		tot = parseInt(timages)-1;
		localStorage.setItem("images",tot);
		ct=localStorage.getItem("images");
		alert(ct);        
        var id = this.id;
        var split_id = id.split("_");
        var deleteindex = split_id[1];

        // Remove <div> with id
        $("#div_" + deleteindex).remove();
    });                
});
  


  </script>