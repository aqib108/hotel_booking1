<?php
/*use Jenssegers\Mongodb\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\Models\Catgry;
use App\Models\Productsimagesmodel;
use App\Models\suppliers;
  function myfun()
  {
      return 'hello';
  }
function changeDateFormate($date,$date_format){
    return \Carbon\Carbon::createFromFormat('Y-m-d', $date)->format($date_format);    
}
   function getsupplier()
   {
    $query = DB::table('supplier')
                ->select('*');
    $resultData = $query->get()->toArray();
   return $resultData;
   }
   
   function getcatgries()
   {
    
    //$resultData = $query->get()->toArray();
   // print_r($resultData);
    //exit;
   return Catgry::all()->toArray();
   }
   function getcatgryname($id)
   {
    
    //$resultData = $query->get()->toArray();
   // print_r($resultData);
    //exit;
     $data= Catgry::where('id',$id)->get()->toArray();
     return $data[0]['name'];
   }
   //function get subcatgry
//function get out stock
function getoutstock($id)
{
 
 //$resultData = $query->get()->toArray();
// print_r($resultData);
 //exit;
 $result = 0;
  $data= DB::table('tbl_out_stock')->where('stock_id',$id)->get()->toArray();
  if(!empty($data))
  {
    foreach($data as $d)
    {
  
      $result = $result + $d->out_stock;
  
    }
  }
  else
  {
$result = 0;
  }
  

  return $result;
}

//end of get out stock

function getstocktitle($id)
{
 
 //$resultData = $query->get()->toArray();
// print_r($resultData);
 //exit;
  $data= DB::table('products')->where('id',$id)->get()->toArray();
  return $data[0]->title;
}

   function getsubcatgryname($id)
   {
    
    //$resultData = $query->get()->toArray();
   // print_r($resultData);
    //exit;
     $data= Catgry::where('id',$id)->get()->toArray();
     return $data[0]['name'];
   }

   //end of getsubcatgry
function productImagePath($image_name)
{
    return public_path('uploads/'.$image_name);
}
///function to get product images
function getproimages($id)
{
 return Productsimagesmodel::where('product_id',$id)->get()->toArray();
}

//end of product images
function setsession($sname,$sdata)
{
    session()->put($sname,$sdata);
}
//end of set session
//get supplier data
function getsupplierdata($id,$gfeild_name,$sfeild_name,$modal_name)
{
    $data= suppliers::where($sfeild_name,$id)->get()->toArray();
    return $data[0][$gfeild_name];
}

//end of supplier data
///get active class*/
function getActive($url)
{
    $lurl=request()->segment(1);
if($url==$lurl)
{
return 'active';
}

}
?>