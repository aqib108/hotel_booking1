<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    //
    public function index()
    {
        $title = 'Hotel Booking Admin';
        return view('admin.index',compact('title'));
    }
    public function hotels()
    {
        $title = 'Register Hotel';
        $data = array();
        return view('admin.hotel',compact('title','data'));

    }
    public function users()
    {
        $title = 'Register Users';
        $data = array();
        return view('admin.users',compact('title','data'));

    }
}
