<?php

namespace App\Http\Controllers;

use App\Models\Room;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function dashboard(Request $request)
    {
        if(Auth::check())
        {
            $data = [];
            
            if(Auth::user()->user_type == 3)
            {
                $hotelId = Auth::user()->id;

                $roomsObj = new Room();
                $rooms = $roomsObj->getAllRoomsOfHotel($hotelId);
                $data['rooms'] = $rooms;
                return view('pages.dashboard', ['data' => $data]);
            }
            else
            {


                return view('pages.userDashboard', ['data' => $data]);
            }

        }
        else
        {
            return redirect('login');
        }
    }
}
