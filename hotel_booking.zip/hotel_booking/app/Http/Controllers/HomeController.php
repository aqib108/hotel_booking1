<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $data = [];

        return view('pages.home');
    }
    function signup_page()
    {
        return view('pages.signup');
    }


    public function aboutUS()
    {
        $data = [];

        return view('pages.aboutUs', ['data' => $data]);
    }

    public function contactUs()
    {
        $data = [];

        return view('pages.contactUS', ['data' => $data]);
    }


}
