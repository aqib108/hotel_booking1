<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<style>
.container{
    width:50%;
    height:30%;
    padding:20px;
}
</style>
</head>
 
<body>
    <div class="container">
        <div class="row">
          <p>{{$data['message']}}</p>
          <br><br>
          <p><b>Regards,</b></p>
          <p>Biplab Sinha</p>
          <p>PHP Consultant</p>
          <p>Indigi Consulting and Solutions Pvt Ltd</p>
        </div>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 
</body>
</html>